public class RB {
  private String[] programmspeicher = null;
  private int anzahlKommandos = 0;
  private int zustand = 0;
  private int[] register = null;
  public int programmHochladen(String[] programm){
    //programmspeicher = programm;
    return 0;
  }
  public String schritt(){
    return "End";
  }
}
