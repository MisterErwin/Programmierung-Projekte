public class Wrapper
{
    public int i;
}
