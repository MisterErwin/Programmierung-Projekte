
/**
 * Enumeration class Material - Lists the potential materials to be drilled on
 */
public enum Material
{
    Wood, Plastic, Metal, Stone, Concrete, ReinforcedConcrete;
}
